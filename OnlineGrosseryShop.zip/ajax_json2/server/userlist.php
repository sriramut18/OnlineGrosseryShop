<?php
//I, VRAJANG SHAH, student 000826893, certify that this material is my original work. No other person's work has been used without due acknowledgment 
//and I have not made my work available to anyone else.

include "connect.php";
include "user.php";

// Prepare and execute the DB query
$command = "SELECT id, item, quantity,price FROM shoppinglist ORDER BY id";
$stmt = $dbh->prepare($command);
$success = $stmt->execute();

// Fill an array with User objects based on the results.
$userlist = [];
while ($row = $stmt->fetch()) {
    $user = new User($row["id"], $row["item"], $row["quantity"],$row["price"]);
    array_push($userlist, $user);
}

// Write the json encoded array to the HTTP Response
echo json_encode($userlist);
