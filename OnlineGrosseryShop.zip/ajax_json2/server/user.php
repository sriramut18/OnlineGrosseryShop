<?php
//I, VRAJANG SHAH, student 000826893, certify that this material is my original work. No other person's work has been used without due acknowledgment 
//and I have not made my work available to anyone else.
class User implements JsonSerializable
{
    private $id;
    private $item;
    private $quantity;
    private $price;

    function __construct($id,$item,$quantity,$price)
    {
        $this->id = (int)$id;
        $this->item = $item;
        $this->quantity = (int)$quantity;
        $this->price = (int)$price;

    }

    /**
     * Returns a string representation of the user object as a list item
     */
    function toListItem()
    {
        return "<li>$this->id $this->item</li>";
    }

    /**
     * Called by json_encode  
     */
    public function jsonSerialize()
    {
        return  get_object_vars($this);
    }
}
