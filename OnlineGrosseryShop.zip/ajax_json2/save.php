<?php

//I, VRAJANG SHAH, student 000826893, certify that this material is my original work. No other person's work has been used without due acknowledgment 
//and I have not made my work available to anyone else.
//this file save all the new enterd items in the database and shows in the shopping list
include "connect.php";

$servername = "localhost";
$username = "root";
$password="";
$dbname="shoppinglist";
// Creating  connection
$conn = new mysqli($servername, $username,$password,$dbname);
// Checking connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$newsql = "INSERT INTO `shoppinglist`(`id`, `item`, `quantity`, `price`) VALUES ('".$_GET['itemsid']."','".$_GET["items"]."','".$_GET["quantity"]."','".$_GET['itemprice']."')";
 
if($conn->query($newsql) === true){
    echo "Records inserted successfully.";
} else{
    echo "ERROR: Could not able to execute $newsql. " . $conn->error;
}	
       



$conn->close();
?>
<!DOCTYPE html>

<html>

<head>
    <title>Ajax with JSON 2</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/ajaxexamples.css">
    <script src="js/getjson.js"></script>
</head>

<body>
    <div id="container">
        <div id="header">
            <h1>WELCOME TO MY SHOPPING LIST</h1>
            <h2>OWNER: VRAJ SHAH</h2>
        </div>
        <div id="body">
        <form action="Save.php" method="GET">
            <label type="id"  >ID:</label>
            <input type="number" name="itemsid" value="1"><br>
            <label type="item"  >ITEM:</label>
            <input type="text" name="items" value=""><br>
            <label type="price"  >PRICE:</label>
            <input type="number" name="itemprice" value="1"><br>
            <label type="quantity"  >QUANTITY:</label>
            <input type="number" id="quantity" value="1"><br>
            <input type="submit" >
            </form>
        </div>

        <div id="body">
            <input type="button" id="clickme" value="SHOW ITEMS">
            <span id="target">

            </span>
            <div id="students"></div>
        </div>
    </div>
</body>

</html>
